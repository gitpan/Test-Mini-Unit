Test::Mini::Unit
================

Test::Mini::Unit began as an attempt to port Ryan Davis' [minitest](http://blog.zenspider.com/minitest/) to Perl, providing a familiar and friendly testing environment for those more familiar with Ruby's test/unit or other similar frameworks.

Despite having been under development for sometime, Test::Mini::Unit is only now getting around to proving itself a viable and dependable testing framework.

Documentation is still fairly scattered, and the API is still prone to churn.  Use at your own risk.  Void where prohibited.